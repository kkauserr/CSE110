//AUTHOR NAME:J.KAUSER
//TITLE:Assignment2.java
//DESCRIPTION: The program asks the user for their full name (first middle last-using nextLine method) as one string in any combination of upper and lower case. Your task is to output the name in the following variations:
//*Print just the initials in upper case letters
//*Print the last name in upper case followed by a comma and the first name in lower case with the first letter capitalized and the middle initial capitalized followed by a period
//*Print the last name comma first name and middle name Â– all names with first letter capitalized.
//TIME AND DATE OF LABS: Wednesdays at 11:15am-12:05pm
//TIME SPENT: 33mins
//DATE: 9/7/2022
/** 
*********************************************************
 */
//PART 1
 //1.  String myString = new String ("Toto, I've a feeling we're not in Kansas anymore.");
 //   a System.out.println(myString.length());
 //   b System.out.println(myString.charAt(myString.indexOf(12));
 //   c myString.indexOf("Kansas");
 //   d myString.indexOf(" ", myString.indexOf(" "));
 //   e myString.substring(6,20);
 //2.  
 //   a true
 //   b true
 //   c false
 //   d true
 
// PART 2
import java.util.*;
import java.lang.*;
public class Assignment2 
{
public static void main(String [] args)
{
	Scanner sc= new Scanner (System.in); //scanner object
	System.out.println("What are your first, middle and last names?");
	String fullname= sc.nextLine(); // input name
	String firstname;
	String middlename;
	String lastname;
	int firstspace= fullname.indexOf(" "); 
	int secondspace= fullname.indexOf(" ", firstspace+1);
	if (firstspace!=-1) {
	firstname=fullname.substring(0, firstspace); // extract first name
	if (secondspace!=-1)
	lastname=fullname.substring(secondspace+1,fullname.length());
	else
	lastname=fullname.substring(firstspace+1,fullname.length()); // extract last name
	char firstinitial= firstname.charAt(0);
    char lastinitial= lastname.charAt(0);
	if (secondspace>=0&&secondspace<fullname.length()) //if condition
	{
		middlename= fullname.substring(firstspace+1,secondspace); // extract middle name
		char middleinitial= middlename.charAt(0);
		String initials= ""+ firstinitial+middleinitial+ lastinitial;
		System.out.println("\nYour initials are: "+ initials.toUpperCase());
		System.out.println("Variation One: "+ lastname.toUpperCase()+ "," +" " + firstname.substring(0, 1).toUpperCase() + firstname.substring(1)+ " "+middlename.substring(0, 1).toUpperCase()+"." );
		System.out.println("Variation Two: "+ lastname.substring(0, 1).toUpperCase() + lastname.substring(1)+","+ " " +firstname.substring(0, 1).toUpperCase() + firstname.substring(1) + " " + middlename.substring(0, 1).toUpperCase() + middlename.substring(1));
	}
	else 
		{
		String initials= ""+ firstinitial+ lastinitial;
		System.out.println("Your initials are: "+ initials.toUpperCase());
		System.out.println("Variation One: "+ lastname.toUpperCase()+ "," + " " + firstname.substring(0, 1).toUpperCase() + firstname.substring(1));
		System.out.println("Variation Two: "+ lastname.substring(0, 1).toUpperCase() + lastname.substring(1)+","+ " " +firstname.substring(0, 1).toUpperCase() + firstname.substring(1));
		}
	}
	else 
	{
		System.out.println("Wrong. Please enter your names properly.");
	}
}
}
