/*-------------------------------------------------------------
//AUTHOR: J.Kauser
//FILENAME: Student.java
//SPECIFICATION: In this lab, we are going to learn how to create an abstract data type, or a class, in Java to help store 
//some data. At the same time, we will practice and get used to the idea of variable scopes and how a 
//Java program calls methods in the runtime
//FOR: CSE 110 - Lab #7
//TIME SPENT: 27mins
//-----------------------------------------------------------*/
public class Student 
{
	String fullName, id;                                 //instance variables
	double grade;
	int numUpdate=0;                                    // instance variable to count the number of times info updated
	int numAccessed=0;                                  // instance variable to count the number of times info accessed
public void setFullName(String name)                    //mutator method to set name
{
	numUpdate++;                                       //incrementing update
	fullName=name;
}
public void setId( String ids)                         //mutator method to set id number
{
	numUpdate++;                                       //incrementing update
	id=ids;
}
public void setGrade (double grades)                   // mutator method to set grade
{
	numUpdate++;                                       //incrementing update
	grade=grades;
}
public String getFullName()                            //accessor method to access name
{
	numAccessed++;                                     //incrementing access
	return fullName;
}
public String getId()                                 //accessor method to access id
{
	numAccessed++;                                    //incrementing access
	return id;
}
public double getGrade()                             //accessor method to access garde
{
	numAccessed++;                                   //incrementing access
	return grade;
}
public int getNumUpdated()                           //accessor method to access number of times updated
{
	numAccessed++;                                   //incrementing access
	return numUpdate;
}
public int getNumAccessed()                          //accessor method to access number of times accessed
{
	numAccessed++;                                  //incrementing access
	return numAccessed;
}
}
