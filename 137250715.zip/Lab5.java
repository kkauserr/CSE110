//AUTHOR NAME: J.KAUSER
//FILENAME: Lab3.java
//SPECIFICATION: design a program that can produce different patterns according to the user input.
//based on the user’s input. 
//FOR: CSE-110- LAB 5
//TIME SPENT:40mins
import java.util.Scanner;
public class Lab5 
{ 
	
	    public static void main(String[] args) 
	    {
	    	final char SIDE_SYMB = '-';
	        final char MID_SYMB = '*';
	        Scanner scanner = new Scanner(System.in);//scanner object
	        String inputStr = "";
	        char choice = ' ';
	        int numSymbols = -1, sideWidth = -1, midWidth = -1;

	        do {// do loop
	            displayMenu();
	            inputStr = scanner.nextLine();//inputting choice
	            if (inputStr.length() > 0) {
	                choice = inputStr.charAt(0);
	            }

	            switch (choice) {//switch case
	            case 'r'://checking for r
	                System.out.println("Width of the sides?");
	                sideWidth = scanner.nextInt();//inputting width of sides from user
	                System.out.println("Width of the middle?");
	                midWidth = scanner.nextInt();//inputting width of middle from user
	                scanner.nextLine(); 
                    System.out.println();
	                System.out.println(buildRow(SIDE_SYMB, sideWidth, MID_SYMB, midWidth));//printing row

	                break;
	            case 'p'://checking for p
	                System.out.println("Number of symbols on the lowest layer?");
	                numSymbols = scanner.nextInt(); //inputting number of symbols
	                scanner.nextLine();  
                    System.out.println();
	                System.out.println(buildPyramid(SIDE_SYMB,MID_SYMB,numSymbols));//printing pyramid

	                break;
	            case 'd'://checking for d
	                System.out.println("Number of symbols on the middle layer?");
	                numSymbols = scanner.nextInt();//inputting number of symbols
	                scanner.nextLine();  

	                System.out.println();
	                System.out.println(buildDiamond('*', ' ', numSymbols));//printing diamond

	                break;
	            case 'q'://checking for d
	                System.out.println("Bye");
	                break;
	                
	            default:
	                System.out.println("Please choose a valid option from the menu.");
	                break;
	            }
	            System.out.println();
	        } while (choice != 'q');
	        
	        scanner.close();
	    }
	    
	    private static String buildRow(char sideSymb, int sideWidth, char midSymb, int midWidth) //helper method to build rows
	    {

	        String result ="";
            String side="";
            String middle="";
	        for (int i=0;i<sideWidth;i++)
	        {
	        	side=side+sideSymb;
	        }
	        for (int j=0;j<midWidth;j++)
	        	middle=middle+midSymb;
	       result=side+middle+side;//constructing row
           return result;
	    }  //end of buildRow

	    private static String buildPyramid(char sideSymb, char midSymb, int numSymbols)//helper method to build pyramids
	    {

	        String result = "";
	        int sideWidth = -1, midWidth = -1;
	        String row="";
	        if (numSymbols==0)
	        	return result;
	        else if (numSymbols%2==0)//checking if even
	        {
	        	System.out.println("The input is not an odd number. Use the closest odd number below " +numSymbols);
	        	numSymbols-=1;
	        }
	        for (int k=numSymbols;k>=0;k-=2) 
	        {
	           midWidth=k;
               sideWidth=(numSymbols-k)/2;
	           row=buildRow(sideSymb,sideWidth,midSymb,midWidth);
               result=row+'\n'+result;//constructing pyramid
	        }
            return result;
	    }//end of buildPyramid
	    private static String buildPyramidReverse(char sideSymb, char midSymb, int numSymbols) //helper method to build reverse pyramid
	    {

	        String result = "";
	        int sideWidth = -1, midWidth = -1;
	        String row="";
	        if (numSymbols==0)
	        	return result;
	        else if (numSymbols%2==0)//checking if even
	        	numSymbols-=1;
	        for (int k=numSymbols;k>=0;k-=2) 
	        {
	           midWidth=k;
               sideWidth=(numSymbols-k)/2;
	           row=buildRow(sideSymb,sideWidth,midSymb,midWidth);
               result=result+'\n'+row;//constructing reverse pyramid
               }
             return result;  
	    }//end of buildReversePyramid

	    private static String buildDiamond(char sideSymb, char midSymb, int numSymbols) //helper method to build diamond
	    {

	        String result = "";
	        String upperPyr="";
	        String lowerPyr="";
	        if (numSymbols==0)
	            return result;
	        else if (numSymbols%2==0)//checking if even
	        {
	        	System.out.println("The input is not an odd number. Use the closest odd number below " +numSymbols);
	        	numSymbols-=1;
	        }
	        upperPyr=buildPyramid(sideSymb,midSymb,numSymbols);//constructing upper half of diamond
	        lowerPyr=buildPyramidReverse(sideSymb,midSymb,numSymbols);//constructing lower half of diamond
	        result=upperPyr.trim()+'\n'+'\n'+lowerPyr.trim();//getting rid of unnecessary whitespaces
	        return result;
    }//end of buildDiamond
	     
	    private static void displayMenu() 
	    {
	        System.out.println("Please choose one pattern from the list:");
	        System.out.println("r) Row");
	        System.out.println("p) Pyramid");
	        System.out.println("d) Shallow diamond");
	        System.out.println("q) Quit");
	      // End of displayMenu

	   }  // End of Lab5
	
}

	
