    //AUTHOR NAME: J.KAUSER
	//FILENAME: Lab3.java
	//SPECIFICATION:Your task is to design a program which takes 3 user inputs as homework grade, mid term exam 
    //grade, and final exam grade. Then use the following formula to calculate the weighted total: 
    //FOR: CSE-110- LAB 3
	//TIME SPENT:20mins
//**************************************************************************************************************************************
import java.util.*;
public class Lab3 
{
	public static void main (String [] args)
	{
		Scanner sc = new Scanner (System.in);
		int hw=0;
	    int midterm=0;
	    int finalexam=0;
		int i=0;
		while (i<3) 
		{
			if (i==0)
			{
				System.out.println("Enter your HOMEWORK grade: ");
				 hw= sc.nextInt();
				if(hw>=0 && hw<=100)
				 {
					 i++;
				 }
				 else if (hw<0 || hw>100)
				{
					System.out.println("[ERR] Invalid input. A homework grade should be in [0,100]");
				}
			} 
			else if (i==1)
			{
				System.out.println("Enter your MIDTERM EXAM grade: ");
				midterm= sc.nextInt();
				if(midterm>=0 && midterm<=100)
				 {
					 i++;
				 }
				else if (midterm<0 || midterm>100)
				{
					System.out.println("[ERR] Invalid input. A midterm grade should be in [0,100]");
				} 
		     }
			else if (i==2)
			{
				System.out.println("Enter your FINAL EXAM grade: ");
				 finalexam= sc.nextInt();
				 if(finalexam>=0 && finalexam<=200)
				 {
					 i++;
				 }
				 else if (finalexam<0 || finalexam>200)
				{
					System.out.println("[ERR] Invalid input. A final grade should be in [0,200]");	
				}
					
			}
		}
		
		double weightedtotal= ((finalexam/200.0)*50.0)+(midterm*0.25)+(hw*0.25);
		 System.out.printf("[INFO] Student's Weighted Total is "+"%.2f", weightedtotal);
		 if (weightedtotal>=50)
		 {
			 System.out.println("\n[INFO] Student PASSED the class");
	     }
		 else 
			 System.out.println("\n[INFO] Student FAILED the class");
	}

}
