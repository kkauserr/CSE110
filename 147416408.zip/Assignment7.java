/*-------------------------------------------------------------------------
// AUTHOR: J. kauser
// FILENAME: Assignment7.java
// SPECIFICATION: This class prompts a user to enter a size for the array
//          and create a Collection object. Then it displays
//          a menu to a user, and process a requested task accordingly.
// FOR: CSE 110- Assignment #7- MWF 9:00 am
// TIME SPENT: 47mins
//----------------------------------------------------------------------*/
import java.util.*;
public class Assignment7
 {
  public static void main(String[] args)
   {
      Scanner scan = new Scanner(System.in);
      int number, size;
      String input, choice;
      char command;
      // ask a user for a array size
      System.out.println("Please enter a size for the array.\n");
      size = scan.nextInt();
      // instantiate a Collection object
      Collection collection = new Collection(size);
      // print the menu
      printMenu();
      do
       {
           // ask a user to choose a command
           System.out.println("\nPlease enter a command or type ?");
           choice = scan.next().toLowerCase();
       command = choice.charAt(0);
           switch (command)
            {
                 case 'a': // add
                      System.out.println("\nPlease enter a string to add.");
                       input= scan.next();
                      collection.add(input);
                      break;
                 case 'b': // remove
                      System.out.println("\nPlease enter a string to be removed.");
                      input = scan.next();
                      collection.remove(input);
                      break;
                 case 'c': // display
                      System.out.print(collection);
                      break;
                 case '?':
                      printMenu();
                      break;
                 case 'q':
                      break;
                 default:
              System.out.println("Invalid input");
            }
        } while (command != 'q');
    }  //end of the main method
  // this method prints out the menu to a user
  public static void printMenu()
   {
    System.out.print("\nCommand Options\n"
                   + "-----------------------------------\n"
                   + "a: add a string to the list\n"
                   + "b: remove a string from the list\n"
                   + "c: display the list\n"
                   + "?: display the menu again\n"
                   + "q: quit this program\n\n");
    } // end of the printMenu method
 } // end of the class
