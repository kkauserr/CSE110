import java.util.Arrays;

/*-------------------------------------------------------------------------
// AUTHOR: J.kauser
// FILENAME: Collection.java
// SPECIFICATION: assignment is to implement a class called Teacher (there is no main method).
// Lab: W 11:15am Ayushi Agarwal
// FOR: CSE 110- Assignment7 - MWF 9:05am
// TIME SPENT: 48mins
//----------------------------------------------------------------------*/
/* PART 1
  1) char [] array= new char[10];
     for (int i=0; i<array.length; i++)
     {
     array[i]='A';
     }
  2) d
  3) int [] array= new int[10];
     array[2]=5;   
  4) 1   
 */

//PART 2:
public class Collection {
	String [] myData;  //instance arrays and variable
	int count=0;
	int sizeArray=0;
	public Collection(int arraySize)
	{
		sizeArray=arraySize;
		myData= new String[sizeArray];
	}
	private int indexOf(String str)
	{
		for (int i=0;i<count;i++)//for loop
		{
			if(myData[i].equals(str))//checking is string exists
				return i;
				
		}
		return -1;
	}
	private void doubleCapacity()
	{
			   String[] newmyData = Arrays.copyOf(myData, 2*myData.length);//doubling string size
			   myData = newmyData;
	}
	public boolean add(String stringToAdd)
	{
		
		if(indexOf(stringToAdd)==-1 && count<myData.length)//checking
		{
			myData[count]=stringToAdd;//adding string
			count++;//incrementing count
			return true;
		}
		else if (indexOf(stringToAdd)==-1 && count>=myData.length) 
		{
			doubleCapacity();
			myData[count]=stringToAdd;//adding string
			count++;//incrementing count
			return true;
		}
		else 
			return false;
		
	}
	public boolean remove(String stringToRemove)
	{
		if(indexOf(stringToRemove)!=-1)//checking
		{
			myData[indexOf(stringToRemove)]=myData[count-1];//replacing string
			myData[count-1]=null;//deleting string
			count--;//decrementing count
			return true;
		}
		return false;
		
	}
	public String toString()
	{
		String ans="";
		for(int k=0;k<count-1;k++)//for loop
		{
			ans= ans+myData[k]+", ";//creating answer 
		}
		return "["+ans+myData[count-1]+"]";//returning final answer
	}
	
}
