    //AUTHOR NAME: J.KAUSER
	//FILENAME: Lab1.java
	//SPECIFICATION: your friend Jenny has a class that gives three tests. She would like you to write a program that will take the three 
	//test grades as input and tell her what her average test grade is. For this Lab you are required to write a program that 
    //will read three test grades from the user and then calculate and print the average of those grades. 
    //FOR: CSE-110- LAB 1
	//TIME SPENT:5mins 
import java.util.Scanner;
public class Lab1 
{
	
	public static void main( String [] args)
	{
		Scanner sc= new Scanner(System.in);  //scanner input
		System.out.print("Enter the score on the first test: ");
		int test1=sc.nextInt();              // reading first test score
		System.out.print("Enter the score on the second test: ");
		int test2=sc.nextInt();             // reading second test score
		System.out.print("Enter the score on the third test: ");
		int test3=sc.nextInt();             // reading third test score
		double avg= (test1+test2+test3)/3.0; // calculating average marks
		System.out.println("The average test score is"+" "+avg);
	}
}
