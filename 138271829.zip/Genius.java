class Genius
{
	String gname;//instance variable
	int NumberOfQs;//instance variable
	public Genius (String name) 
	{
		gname=name;
		NumberOfQs=0;
	}
	public String getName()//method to get name
	{
		return gname;
	}
	public int getNumberOfQuestions()//method to get number of questions asked
	{
		return NumberOfQs;
	}
	public boolean isOdd (int num)// to determine odd number
	{
		NumberOfQs++;
		if(num%2==0)
			return false;
		else 
			return true;
		}
	public String reverse(String text)//to reverse a string
	{
		NumberOfQs++;
		String reverse="";
	    for (int i=0;i<text.length();i++)
	    {
	    	reverse=text.charAt(i)+reverse;
	    }
	    return reverse;
	}
	public int factorial(int num)//to calculate factorial
	{
		NumberOfQs++;
		int factorial=1;
		for (int i=1; i<=num; i++)
		{
		  factorial=factorial*i;	
		}
		return factorial;
	}
	public boolean isAlpha (char letter)//to check if it is an alphabet
	{
		NumberOfQs++;
		if(Character.isUpperCase(letter) || Character.isLowerCase(letter))
			return true;
		else 
			return false;
			
	}
	public int smallest(int num1, int num2, int num3)// to determine the smallest integer
	{
		NumberOfQs++;
		if(num1<num2)
		{
			if(num3<num1)
				return num3;
			else 
				return num1;
		}
		else
		{
			if (num2<num3)
			    return num2;
				else 
					return num3;
			
			}
		
		}
	public boolean isPrime(int num)// to check if its prime
	{
		NumberOfQs++;
		int count=0;
		if(num>1)
		{
		for (int i=1; i<=num; i++)
		{
		 if(num%i==0)
			 count++;
		}
		if(count==2)
			return true;
			else 
				return false;
	}
	return false;
	}
}

