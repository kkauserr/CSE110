
/*-------------------------------------------------------------------------
// AUTHOR: J.kauser
// FILENAME: Assignment5.java
// SPECIFICATION:  This program provides a menu and based on user input calls the method in class Geek
// YOUR Lab Letter and Name of the TA for your Closed lab
// FOR: CSE 110- homework #5- MWF 9:05am
// TIME SPENT: 30mins
//----------------------------------------------------------------------*/

import java.util.*;

public class Assignment5
{
   public static void main (String[] args)

   {
       Scanner console = new Scanner (System.in);

       String choice;
	   char command;

        // print the menu
		      printMenu();
		      Genius myGenius = new Genius("Albert Einstein");
		      do
		       {
		           // ask a user to choose a command
		           System.out.println("\nPlease enter a command or type ?");
		           choice = console.next().toLowerCase();
	               command = choice.charAt(0);

		           switch (command)
		           {
		                 case 'a':// return name
		                      System.out.println(myGenius.getName());
		                      break;
		                 case 'b': //returns number of questions asked
		                      System.out.println(myGenius.getNumberOfQuestions());

		                      break;
		                 case 'c': //finds if a number is odd or even
							  System.out.print("Enter a number: ");
							  int num = console.nextInt();
							  if (myGenius.isOdd(num))
							  		System.out.println(num + " is odd");
							  else
							        System.out.println(num + " is not odd");
		                      break;
		                 case 'd': //reverse a string
							  System.out.print("Enter a String: ");
							  String input = console.next();
							  System.out.println(myGenius.reverse(input));
		                      break;
		                 case 'e': //finds the factorial
                                                          System.out.print("Enter an integer: ");
							  num = console.nextInt();
							  System.out.println(num + "! is: " + myGenius.factorial(num));
		                      break;
		                 case 'f': //finds if it is alphabet
							  System.out.println("Enter a character: " );
							  input = console.next();
							  char letter = input.charAt(0);
							  if (myGenius.isAlpha(letter))
							     System.out.println("It is an alphabet");
							  else
							     System.out.println("It is NOT an alphabet");
		                      break;

		                 case 'g'://finds the smallest integer
		                        System.out.println("Enter 3 integers: ");
		                        int a = console.nextInt();
		                        int b = console.nextInt();
		                        int c = console.nextInt();
		                        System.out.println("The smallest integer is: " + myGenius.smallest(a, b, c));
		                        break;

		                 case 'h'://finds if number is prime
		                 		System.out.println("Enter an integer: ");
		                 		num = console.nextInt();
		                 		if (myGenius.isPrime(num))
		                 		    System.out.println(num + " is prime");
					         else
					            System.out.println(num + " is not prime");
					         break;
		                 case '?':
		                      printMenu();
		                      break;
		                 case 'q':
		                      break;

		                 default:
		                       System.out.println("Invalid input");

		            }

		        } while (command != 'q');

		    }  //end of the main method


		  public static void printMenu()
		   {
		    System.out.print("\nCommand Options\n"
		                   + "-----------------------------------\n"
		                   + "a: get name\n"
		                   + "b: number of questions asked\n"
		                   + "c: is Odd\n"
		                   + "d: reverse\n"
		                   + "e: factorial\n"
		                   + "f: is Alphabetic\n"
		                   + "g: smallest\n"
		                   + "h: Is prime\n"
		                   + "?: display the menu again\n"
		                   + "q: quit this program\n\n");
		    } // end of the printMenu method
}
