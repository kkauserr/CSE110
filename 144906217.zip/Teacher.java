
/*-------------------------------------------------------------------------
// AUTHOR: J.kauser
// FILENAME: Assignment6.java
// SPECIFICATION: assignment is to implement a class called Teacher (there is no main method).
// Lab: W 11:15am Ayushi Agarwal
// FOR: CSE 110- homework #5- MWF 9:05am
// TIME SPENT: 30mins
//----------------------------------------------------------------------*/
/* PART 1
  1) an error message appears in output saying that since str is null str.lrnght() cannot be executed or called.
     yes, output:
     null
     *Error Message*
  
  2) new BankAccount(5000);- creates and initializes a newly constructed bank account object to values 5000.
     BankAccount b;- creates an object but doesnt initialize it.
 */

//PART 2:
import java.text.NumberFormat;
import java.util.*;
public class Teacher 
{
	String teacherName;
	double teacherSalary;
	int teacherYears;
	private static int numOfTeachers=0;
public Teacher()                                    //constructor without parameters to assigning default initial values
{
	numOfTeachers++;                               //incrementing number of teachers
	teacherName="???";                  
	teacherSalary=0.0;
	teacherYears=0;
}
public Teacher( String name, double salary, int years) //constructor with parameters
{
	numOfTeachers++;                                  //incrementing number of teachers
	teacherName=name;
	teacherSalary=salary;
	teacherYears=years;
}
public Teacher(String str)
{
	numOfTeachers++;                              //incrementing number of teachers
	teacherName= str.substring(0,str.indexOf(':')); //obtaining name
	teacherSalary=Double. parseDouble((str.substring((str.indexOf(':')+1),str.lastIndexOf(':'))));//obtaining salary
	teacherYears=Integer.parseInt(str.substring(str.lastIndexOf(':')+1,str.length()));//obtaining years of experience
}
public String getName()//returning name
{
	return teacherName;
}
public int getYears()//returning salary
{
	return teacherYears;
}
public double getSalary()//returning years of experience
{
	return teacherSalary;
}
public void setYears()//incrementing years
{
	teacherYears++;
}
public void raiseSalary (double byPercent)//raising salary
{
	teacherSalary=(teacherSalary+(teacherSalary*(byPercent/100)));//calculating new salary
}
Teacher makesMore(Teacher x)//comparing teachers
{
	if(this.teacherSalary<x.getSalary())//comparing salaries
		return x;
	return this;
}
public static int getNumTeachers()//returning number of teachers
{
	return numOfTeachers;
}
public String toString()//tostring function
{
	NumberFormat fmt=NumberFormat.getCurrencyInstance(Locale.US);//formatting object for currency format
	return("\nName: "+teacherName+"\nSalary: "+fmt.format(teacherSalary)+"\nYears of Experience: "+teacherYears);
}
}
