

	/*-------------------------------------------------------------------------
	// AUTHOR: CSE110 solution
	// FILENAME: Assignment6.java
	// SPECIFICATION:  This program allows the user to create teacher' objects and 
	performs operations for each teacher object.
	//----------------------------------------------------------------------*/
	import java.util.*;
	public class Assignment6
	{
	public static void main(String[] args)
	   {
	       Scanner console = new Scanner(System.in);
	       String choice;
	   char command;
	      // Create a new teacher object
	      System.out.print("Enter teacher's name? ");
	String name = console.nextLine();
	System.out.print("Enter salary for " + name + "? ");
	        double salary = console.nextDouble();
	System.out.print("Enter number of years for " + name +  "? ");
	int years = console.nextInt();
	Teacher t1 = new Teacher(name, salary, years);
	Teacher t2 = new Teacher("Plato:70000:20");
	        // print the menu
	printMenu();
	do
	{
	       // ask a user to choose a command
	       System.out.println("\nPlease enter a command or type?");
	       choice = console.next().toLowerCase();
	               command = choice.charAt(0);
	           switch (command)
	            {
	                 case 'a': // write the code to print the info for each teacher
	                       System.out.println(t1.toString());
	                       System.out.println(t2.toString());
	                       break;
	                 case 'b': // complete the code to raise teachers' salary and print them
	                      System.out.println("Enter the amount of raise: ");
	                      double raise = console.nextDouble();
	                      t1.raiseSalary(raise);
	                      t2.raiseSalary(raise);
	                      System.out.println(t1.toString());
	                      System.out.println(t2.toString());
	                      break;
	                 
	                      case 'c': //increment the number of years by 1
	                      t1.setYears();
	                      t2.setYears();
	                      System.out.println("Year has been added.");
	                      break;
	                 case 'd': //find who is making more
	                                      Teacher who = t1.makesMore(t2);
	                                      System.out.println(who.getName() + " is making more.");
	                      break;
	                  case 'e': //number of teachers
	      System.out.println("They are " + 
	Teacher.getNumTeachers()+ " teachers.");
	                      break;
	                 case '?':
	                      printMenu();
	                      break;
	                 case 'q':
	                      break;
	                 default:
	                       System.out.println("Invalid input");
	            }
	 } while (command != 'q');
	 console.close();
	}// end main
	     public static void printMenu()
	    {
	    System.out.print("\nCommand Options\n"
	                   + "-----------------------------------\n"
	                   + "'a': prints info \n"
	   + "'b': raise salary\n"
	   + "'c': increment the years of experience\n"
	     + "'d': who makes more\n"
	     + "'e': number of teachers\n"
	   + "'?': Displays the help menu\n"
	   + "'q': quits\n");
	      } // end of the printMenu method
	}

