
/*-------------------------------------------------------------
// AUTHOR: J. Kauser
// FILENAME: Lab9.java
// SPECIFICATION: your own description of the program.
// FOR: CSE 110 - Lab #9
// TIME SPENT: 43mins
//-----------------------------------------------------------*/

import java.util.Scanner;
import java.text.DecimalFormat;

public class Lab9
{
    public static void main(String[] args)
    {
        /* Declare initial variables you need */
        Scanner scanner = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#0.00");

        /* Ask the user for the number of students */
        System.out.print("How many students do you have?");
        int numStudents = scanner.nextInt();
        System.out.println();

        /* Create two arrays: one for groups the other for grades */
        int [] studentGroups = new int[numStudents];//group number array
        double[] studentGrades = new double [numStudents];//grades array
        
        /* A loop to fill up the array of */
        for (int i=0; i<numStudents; i++)
        {
        	System.out.println("[Group #] and [Grade] for Entry "+ i);
        	studentGroups[i]=scanner.nextInt();//inputting group number
        	studentGrades[i]=scanner.nextDouble();//inputting grades
        }

        /* Print out the content of the two arrays as a list (from the back). */
        System.out.println("\n===== List of Student Records =====");
       
        for(int j=numStudents-1; j>=0; j--)//for loop
        {
        	System.out.println("Group "+studentGroups[j] +" " +"- "+ df.format(studentGrades[j])+ " Points");
        }

        /* Print some statistics for each group. You must use the method "printStats" */
        System.out.println("\n===== Group Statistics =====");
        for (int i = 0; i < findTotalNumOfGroups(studentGroups); i++)
        {
            printStats(studentGroups, studentGrades, i + 1);
        }

        /* Clean up */
        scanner.close();
    }

    /**
     * Print out the count and average for targetGroup.
     * 
     * @param groups      an array of all students' groups
     * @param grades      an array of all students' grades
     * @param targetGroup the target group
     */
    private static void printStats(int[] groups, double[] grades, int targetGroup)
    {
        int count = 0;
        double sum = 0;
        double average = 0;

        /* For each record in groups */
        for (int i = 0; i < groups.length; i++)
        {
            /* If we find a record matching targetGroup, update count and sum */
        	if (groups[i]==targetGroup)
        	{
        		count++;//incrementing count
        		sum=sum+grades[i];//calculating sum
        	}
        }

        /* Update the average */
        if (count!=0)
        	{
        	average=sum/count;
        	}
        else average=0.00;
        	

        /* Output */
        System.out.printf("Group #%d has %d student(s), the average is %.2f\n", targetGroup, count, average);
    }

    /**
     * Find out the total number of groups on record. Group numbers are assumed to
     * be a cumulative sequence starting from 1, e.g., [1, 2, 3, 4, 5]. Therefore,
     * the total number of groups is simply the maximum number on a record (array)
     * of group numbers.
     * 
     * @param groups an array of group numbers
     * @return the total number of groups on the record
     */
    private static int findTotalNumOfGroups(int[] groups)
    {
        if (groups == null)
        {
            return 0;
        }

        int numGroups = 0;
        for (int i = 0; i < groups.length; i++)
        {
            if (groups[i] > numGroups)
            {
                numGroups = groups[i];
            }
        }
        return numGroups;
    }

}

