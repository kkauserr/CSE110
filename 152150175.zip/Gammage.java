/*-------------------------------------------------------------------------
// AUTHOR: JKauser
// FILENAME: Gammage.java
// SPECIFICATION: gammage seatings
// FOR: CSE 110- Assignment8.java - MWF 9:00 am
// TIME SPENT: 28mins
//----------------------------------------------------------------------*/
/* PART 2
 * 1.
 * a) 1 5 8 3 4 5
 *    1 3 8 5 4 5 
 *    1 3 4 5 8 5
 *    1 3 4 5 5 8
 *
 * b) 5 8 1 3 4 5 
 *    1 5 8 3 4 5 
 *    1 3 5 8 4 5
 *    1 3 4 5 8 5
 *    1 3 4 5 5 8
 * 
 * 2.
 * a) 3
 * b) 4
 * c) 1
 * d) 2
 */
//PART 2:
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Locale;

public class Gammage {
	double totalSales;
	double [][] seats;
	public Gammage () {
		seats = new double [3][4];
		totalSales = 0.00;
		try
	    {
	          FileReader fr = new FileReader ("seatPrices.txt");
	          BufferedReader inFile = new BufferedReader (fr);
	          String line = inFile.readLine();
	        	 while ( line != null)
	           {   line=line.trim(); 
	           if (line.length()==0)
	        	   continue;
	    	         for(int i=0; i<seats.length; i++) {
	    	         for (int j=0; j<4; j++) {	        		 
	              seats[i][j]=Double.parseDouble(line);
	              line = inFile.readLine();
	            }
	   }
	    }
	         inFile.close();
	     }
	   catch (IOException exception)
	   {
	         System.out.println (exception);
	   }
	}
	public String getTotal() {
		NumberFormat fmt = NumberFormat.getCurrencyInstance(Locale.US);
		return (fmt.format(totalSales));
	}
	public void displayChart() {
        for(int k=0; k<seats.length; k++) {
        	System.out.println();
       	 for (int l=0; l<4; l++) {
       		 System.out.print(seats[k][l]+"\t");
       	 }
       	  }
	}
	public boolean sellTicket(int i, int j) {
		if(i>=3 || i<0)
		{
			System.out.println("\nIllegal row request. Rows are numbered 0 - 3.");
		}
		if (j>=4 || j<0)
		{
			System.out.println("\nIllegal column request. Columns are numbered 0 - 4.");
			
		}
		if (i>=0 && i<3 && j>=0 &&j<4) {
			if(seats[i][j]>0) {
			totalSales+=seats[i][j];
			seats[i][j]=0;
			return true;
		}
		}
		return false;
	}
	public int numSold() {
		int counter=0;
        for(int i=0; i<seats.length; i++){
       	 for (int j=0; j<4; j++){
       		 if (seats[i][j]==0)
       		  counter++;
       	 }
	}
        return counter;
}
	public boolean soldOut()
	{
		int counter=0;
        for(int i=0; i<seats.length; i++){
       	 for (int j=0; j<4; j++){
       		 if (seats[i][j]!=0)
       			 return false;
       			 }
}
        return true;
	}
}
	
