/*-------------------------------------------------------------
// AUTHOR: J. Kauser
// FILENAME: Lab10.java
// SPECIFICATION: In this lab, you are required to create a 2D Array that stores groups of students. Each 
group has a fixed size, however the number of groups can increase. 
// FOR: CSE 110 - Lab #10
// TIME SPENT: how long it took you to complete the assignment
//-----------------------------------------------------------*/
import java.util.Scanner;
import java.text.DecimalFormat;
public class Lab10 {
	static DecimalFormat df = new DecimalFormat("0.00");
    private static final Scanner stdin = new Scanner(System.in);
    private static GroupManager manager;
    public static void main(String[] args) {
        System.out.println("===== Class Group Manager =====");
        
        // retrieve input for number of students
        System.out.print("Enter number of students in class: \n");
        int numStudents;
        numStudents=stdin.nextInt();
        while( numStudents<1)
        {
        	System.out.println("[ERROR] Class must have at least one student");
        	System.out.print("Enter number of students in class: \n");
             numStudents=stdin.nextInt();
        }
        
        // retrieve input for size of each group
        System.out.print("Enter the size of each group: \n");
        int groupSize;
        groupSize = stdin.nextInt();
        while(groupSize<2)
        {
        	System.out.println("[ERROR] Groups must have at least two members");
        	System.out.print("Enter the size of each group: \n");
        	groupSize = stdin.nextInt();
        }
        // calculate the number of groups
        int numGroups;
        if(numStudents%groupSize!=0) {
        numGroups= (numStudents/groupSize)+1;
        }
        else 
        numGroups= (numStudents/groupSize);
        
        // create GroupManager object with specified attributes
        manager = new GroupManager(numGroups,groupSize);// new GroupManagerSolution(...);
        System.out.println("[SUCCESS] Created a new group manager with "+numGroups+" groups (capacity of "+manager.getStudentCapacity()+" students) ");
        // call updateGroups() to populate these groups with their initial value
        //updateGroups();
        // display number of actual students, number of groups, and student capacity
        // run interactive menu
        mainMenu();
    }
    // * THIS METHOD IS COMPLETE * //
    private static void mainMenu() {
        System.out.print(
            "\n===== Main Menu =====\n" +
            "U: Update Groups\n" +
            "A: Add New Group\n" +
            "D: Display Groups\n" +
            "Q: Quit\n" +
            "Selection:\n"
        );
        switch(Character.toUpperCase(stdin.next().charAt(0))) 
        {
            case 'U': // update all groups' grades
                updateGroups();
                break;
            case 'A': // add a new group
                addGroup();
                break;
            case 'D': // display all groups
                displayGroups();
                break;
            case 'Q':
                System.out.println("Exiting...");
                return; // exit the entire method
            default:
                System.out.println("[ERROR] Invalid menu option, please try again...");
        }
        // recursively call the menu function
        mainMenu();
    }
    // * THIS METHOD IS COMPLETE * //
    private static void populateGroup(int[] group, int groupNum) 
    {
        for (int memberNum = 0; memberNum < group.length; memberNum++)
        {
        	int m=memberNum+1;
            do {
            	System.out.printf("Group %d - Enter Member %d's Grade:\n", groupNum+ 1, memberNum + 1);
                group[memberNum] = stdin.nextInt();
                if (group[memberNum] < -1) System.out.println("[ERROR] Grade must be non-negative or -1");
            } while(group[memberNum] < -1);
        }
    }
    private static void updateGroups()
    {
        int numGroups = manager.getNumGroups();
        System.out.println("\n[NOTE] Enter -1 for no member/grade");
        // update every group's grades
        for (int r=0; r<numGroups;r++ )
        {
        	
            populateGroup(manager.getGroup(r),r);
            System.out.println();
        }
    }
    private static void addGroup() 
    {
        // determine group size
        // Hint: use the Manager class' instance methods getStudentCapacity() and get getNumGroups()
    	 int newGroupSize= manager.getStudentCapacity()/manager.getNumGroups();
        // create a new int array with this group size
    	 int [] newgroup= new int [newGroupSize];
        // populate the array with grades and add it to the group
           populateGroup(newgroup, manager.getNumGroups());
           manager.addGroup(newgroup);
        // display success message
           System.out.println("[SUCCESS] Added Group " + manager.getNumGroups()+" to the manager");
    }
    private static void displayGroups() 
    {
 
        System.out.println("\nDisplaying: All Groups (w/ Statistics)");
        int numGroups = manager.getNumGroups();
        // calculate the average of every group and display every member's grade
          for( int r=0; r< numGroups; r++) 
          { 
        	  double avg=0.00;
        	  int sum=0;
        	  int counter=0;
        	  System.out.println("\n=== Group "+(r+1)+" ===");
        	  for (int c=0;c<(manager.getStudentCapacity()/manager.getNumGroups());c++)
        	  {
        		  if ((manager.getGroup(r))[c]==-1)
        			  System.out.println("Member "+ (c+1)+ ": No Student");   
        		  else 
        		  {
        		 System.out.println("Member "+ (c+1)+ ": "+ (manager.getGroup(r))[c]); 
        		 sum=sum+(manager.getGroup(r))[c];
        		 counter++;
        		  }
        	  }
        	  if (counter>0)
        		  {
        		  avg=(sum*1.0)/counter;
        		  }
        	  else avg=0.00;
        	  System.out.println(counter+" Member(s), Average: "+df.format(avg));
          }
    }
}