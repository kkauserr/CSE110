/*-------------------------------------------------------------
// AUTHOR: J. Kauser
// FILENAME: GroupManager.java
// SPECIFICATION: In this lab, you are required to create a 2D Array that stores groups of students. Each 
group has a fixed size, however the number of groups can increase. 
// FOR: CSE 110 - Lab #10
// TIME SPENT: 49mins
//-----------------------------------------------------------*/
import java.util.Arrays;
public class GroupManager 
{
    private int[][] groups;
    private final int GROUP_SIZE;
    private int count = 0;
    public GroupManager(int numGroups, int groupSize) {
        // initialize constant for size of each group
        GROUP_SIZE = groupSize;
        groups= new int [numGroups][GROUP_SIZE];
        // ! grade of -1 indicates "no student"
        // create new 2D int array with dimensions: numGroups x groupSize
        // populate the array with -1 to indicate no grade/member by default
        for (int r=0; r<numGroups;r++)
        {
        	for (int c=0;c<GROUP_SIZE;c++)
        		groups[r][c]=-1;
        }
        // initialize count to the length of the first dimension of this array
        count=numGroups;
        
    }
    public void addGroup(int[] groupToAdd) {
        // check if array is full, if so create a new array double the size and copy all elements over
    	if (count>=getNumGroups())
    	{    
    		int [][]newgroups=new int[getNumGroups()*2][GROUP_SIZE];
    	    for (int r=0;r<getNumGroups();r++)
    	    {
    	    	for (int c=0;c<GROUP_SIZE;c++)
    	    	newgroups[r][c]= groups[r][c];	
    	    }
    	    groups=newgroups;
    	}  
    	    count++;
    	    groups[count-1]= groupToAdd;
    	   
         // Hint: use count as the index the next group will be added to
        
        // add the new group to the end of the array
        // remember to increment count
    }
    public int getStudentCapacity() {
        // return [number of groups added] * [groupSize]
    	return count*GROUP_SIZE;
    }
    public int getNumGroups() {
        // return the number of groups that have been added
    	return count;
    }
    public int[] getGroup(int groupNum) {
        // return group at index "groupNum"
    	return groups[groupNum];
    }
}
