import java.text.DecimalFormat;

public class Student 
{
	String fullName, id;                                 //instance variables
	double grade;
	int numUpdate=0;                                    // instance variable to count the number of times info updated
	int numAccessed=0;                                 // instance variable to count the number of times info accessed
 
	public Student (String n, String asuid, double asugrade) //constructor with parameters
 {
	 fullName=n;
	 id=asuid;
	 grade=asugrade; 
 }
	
	public Student()                                   //constructor without parameters
	{                                                  //assigning default values
		fullName="";
		id= null;
		grade= -1.0;
		numUpdate=0;
		numAccessed=0;
		
	}
public void setName(String name)                       //mutator method to set name
{
	numUpdate++;                                       //incrementing update
	fullName=name;
}
public void setId( String ids)                         //mutator method to set id number
{
	numUpdate++;                                       //incrementing update
	id=ids;
}
public void setGrade (double grades)                   // mutator method to set grade
{
	numUpdate++;                                       //incrementing update
	grade=grades;
}
public String getFullname()                            //accessor method to access name
{
	numAccessed++;                                     //incrementing access
	return fullName;
}
public String getAsuID()                                 //accessor method to access id
{
	numAccessed++;                                      //incrementing access
	return id;
}
public double getGrade()                               //accessor method to access garde
{
	numAccessed++;                                     //incrementing access
	return grade; 
}
public boolean equals (Student other)
{
	if(id!=null && other.getAsuID()!=null)            //checking if string is null
	{
	if (((this.id).toUpperCase()).equals((other.getAsuID()).toUpperCase())) //checking is variables are equal
	return true;
	}
	else if (((this.fullName).toUpperCase()).equals((other.getFullname()).toUpperCase())) //checking is variables are equal
	return true;
	return false;
}
public String getClassStatistics()
{
	numAccessed++;                                     //incrementing access
 int [] studentgrades = {99,85,92,100};                //creating arrays of grades
 double average=0.0;
 double sum=0.0;
 double highest=studentgrades[0];
 double lowest=studentgrades[3];
 System.out.println("Student's grades are:");
for (int i=0; i<studentgrades.length; i++)             //for loop
{
	System.out.println(studentgrades[i]); 
 if (studentgrades[i]>highest)                         //calculating highest grade
	 highest=studentgrades[i];
 if(studentgrades[i]<lowest)                           //calculating lowest grade
	 lowest=studentgrades[i];
 sum+=studentgrades[i];                                //calculating sum of grades
}
average= sum/4.0;                                     //calculating average
return ("\nClass average is: "+ average + "\nLowest grade is: "+ lowest+ "\nHighest grade is: "+ highest);
}
public int getNumOfUpdates()                           //accessor method to access number of times updated
{
	numAccessed++;                                   //incrementing access
	return numUpdate;
}
public int getNumOfAccessed()                         //accessor method to access number of times accessed
{
	numAccessed++;                                  //incrementing access
	return numAccessed;
}
public String toString()                            //toString() 
{
	DecimalFormat fmt= new DecimalFormat("0.00"); //formatting decimal output
	return ("[Name: "+fullName+", ASUID: "+ id +", Grade: "+fmt.format(grade)+"]");
}
}
