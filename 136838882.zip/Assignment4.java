//AUTHOR NAME:J.KAUSER
//TITLE:Assignment1.java
//DESCRIPTION:
//TIME AND DATE OF LABS: Wednesdays at 11:15am-12:05pm
//TIME SPENT: 20mins
//DATE: 9/20/2022
/*PART1
 * a) 7 6 
 * b) 3
 * c) =====
 *    *****
 *    =====
 *    *****
 *    =====
 *    *****
 *    =====
 *    *****
 *    =====
 *    *****
 * d) *****
 *    +****
 *    ++***
 *    +++**
 *    ++++*
 ******************************************************************************************************************************
PART 2
*/
import java.util.Scanner;
public class Assignment4 {
	public static void main (String [] args)
	{
		Scanner sc=new Scanner (System.in);
		int choice=0;
		String yn="";
		for (int i=0; i<2;)
		{ 
			System.out.println("1. Find the gcd");                                    //printing options
			System.out.println("2. Compute");
			System.out.println("Your Choice:");
			choice= sc.nextInt();                                                    //imputing choice from user
			switch(choice)
			{
			case 1://checking for case 1
			{
				int int1=0;
				int int2=0;
				int x=0;
				int y=0;
				System.out.println("Enter the first integer: ");
				int1=sc.nextInt();                                                  //inputing first number
				System.out.println("x = "+int1);
				System.out.println("Enter the second integer: ");
				int2=sc.nextInt();                                                 //inputting second integer
				System.out.println("y = "+int2);
				x=int1; 
				y=int2; 
				while(x!=0 && y!=0)                                                // loop for calculating gcd
				{
				if(x>=y)
					x=x-y;
				else
				    y=y-x;
				}
				System.out.println("The gcd of " + int1+ " and " +int2+" is " +(x+y));
				System.out.println("Do you want to continue?(Yes/No):");
				yn= sc.next();                                                    //inputing choice to continue or no
				if( yn.equals("yes") || yn.equals("Y") || yn.equals("y") || yn.equals("Yes"))
				{
					i=1;
				}
				else 
					System.exit(0);                                               //terminating program
			}
				break;
			case 2://checking for case 2
				{
				int number=0;
				int largest=0;
				int counteven=0;
				int countodd=0;
				int sum=0;
				int smallest=Integer.MAX_VALUE;
				String cumsum="";
				System.out.println("Enter a sequence of integers, -1 to quit: ");
				while (sc.hasNext())                                               //loop for inputing sequence of numbers
				{
		            number= sc.nextInt();
		            if(number == -1)                                              //condition to stop when -1 is entered
		            {
		                 break;
		            }
				  if (number>largest)                                            //finding largest number
					  largest=number;
				  if(number<smallest)                                           //finding smallest number
					  smallest=number;                                          //calculating sum
				  sum=sum+number;
				  cumsum=cumsum+sum+" ";                                        //converting sum into string
				  if(number%2==0)                                               //finding even numbers
					  counteven++;
				  else 
					  countodd++;                                               //finding odd numbers
				}
				System.out.println("Largest: "+ largest);
				System.out.println("Smallest: "+ smallest);
				System.out.println("Number of even: "+counteven);
				System.out.println("Number of odd: "+countodd);
				System.out.println("Cumulative sum is: "+cumsum);
				System.out.println("Do you want to continue?(Yes/No):");
				yn= sc.next();
				if( yn.equals("yes")|| yn.equals("Y") || yn.equals("y") || yn.equals("Yes"))
				{
					i=1;
				}
				else 
					System.exit(0);                                           //terminating the program
				}
				break;
			}
			
		}
	}

}
