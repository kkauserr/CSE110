
    //AUTHOR NAME: J.KAUSER
	//FILENAME: Lab3.java
	//SPECIFICATION:In this lab, you need to design a program that can perform three different arithmetic operations 
    //based on the user’s input. 
    //FOR: CSE-110- LAB 4
	//TIME SPENT:20mins
//********************************************************************************************************************************************
import java.util.*;
public class Lab4 
{
	public static void main (String [] args)
	{
		Scanner sc= new Scanner (System.in);
		int sum=0;                                                                      // initialising sum variable
		int factorial=1;                                                               // initialising factorial variable
		for (int j=0; j<2;) {
		System.out.println("Please choose one option from the following menu:");       // printing options
		System.out.println("1) Calculate the sum of integers from 1 to m");
		System.out.println("2) Calculate the factorial of a given number");
		System.out.println("3) Display the leftmost digit of a given number");
		System.out.println("4) Quit");
		int choice= sc.nextInt();                                                    // inputting choice from user
		switch (choice)                                                              // checking choice through switch
		{
		case 1:                                                                     // checking for choice one
		{
			System.out.println("Enter a number:");
			int n=sc.nextInt();
			for (int i=1; i<=n; i++)                                              //for loop for sum
			{
			 sum=sum+i;                                                          // calculating sum
			}
			System.out.println("The sum of 1 to " +n+ " is "+ sum);
			j=1;
		}
		break;
		case 2:	                                                                 //checking for case 2
		{
			System.out.println("Enter a number:");
			int m=sc.nextInt();
			for (int i=1; i<=m; i++)                                             //for loop for factorial
			{
			 factorial= factorial*i;                                            //calculating factorial
			}
			System.out.println("The factorial of " +m+ " is "+ factorial);
			j=1;
		}
		break;
		case 3:                                                                   //checking for case 3
		{
			System.out.println("Enter a number:");
			int p=sc.nextInt();
			String p2 = ""+p;                                                     //converting int to string
			System.out.println("The leftmost digit of " +p+" is "+ p2.charAt(0));
			j=1;
		}
		break;
		case 4:                                                                    //checking for case 4
			{
				System.out.println("Bye");
				j=2;
				break;
				}
		}
		}
		
	}

}

